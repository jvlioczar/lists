# Top 100 BR Instagram — Static Embed

Site estático para hospedar no **GitHub Pages** / **Netlify** e incorporar via **iframe** no WordPress.com (plano gratuito).  
Ele lê os dados de uma **Google Sheets publicada como CSV**, que você atualiza diariamente com **Google Apps Script** (cron).

## Como usar

1. **Planilha**  
   - Crie/abra a planilha com as colunas: `rank, name, username, profile_url, followers, last_checked`.  
   - Atualize os dados via Apps Script (veja o script fornecido na conversa).

2. **Publicar CSV**  
   - No Google Sheets: `Arquivo` → `Publicar na Web` → Selecione a aba certa → **Formato: CSV** → `Publicar`.  
   - Copie o link gerado (termina com `output=csv`).

3. **Configurar o site**  
   - Edite `assets/app.js` e cole a URL no `SHEET_CSV_URL`.  
   - Opcional: personalize estilos em `assets/style.css` e título/meta em `index.html`.

4. **Hospedar**  
   - **GitHub Pages**:  
     - Crie um repositório (público).  
     - Faça upload desses arquivos na raiz.  
     - Settings → Pages → Source = `Deploy from a branch`, Branch = `main` (ou `master`) / `/root`.  
     - A URL ficará algo como `https://SEU_USUARIO.github.io/NOME_REPO/`.
   - **Netlify**: arraste e solte a pasta neste projeto no painel do Netlify e pegue a URL.

5. **Incorporar no WordPress.com**  
   - No editor de páginas: adicione um bloco **HTML** ou **Incorporar**.  
   - Cole o iframe:
     ```html
     <iframe src="https://SEU_USUARIO.github.io/NOME_REPO/" width="100%" height="900" style="border:0; border-radius:12px; overflow:hidden"></iframe>
     ```
   - Ajuste `height` conforme necessário. (Dica: você pode implementar auto-resize com `postMessage` se editar o host.)

## Observações

- A ordenação e filtros são do DataTables no lado do cliente.  
- O CSV é revalidado a cada carregamento. Como seu Apps Script roda diariamente, o front sempre recebe os números atualizados.  
- Se quiser histórico e gráficos, publique outra aba com `username,date,followers` e amplie `app.js` para desenhar com Chart.js.

## Termos / Ética

Scraping de Instagram pode violar termos; use por sua conta e risco. Prefira intervalos maiores e autenticação (sessionid) para reduzir erros.
