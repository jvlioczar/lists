// CONFIGURE AQUI: cole o link CSV publicado da sua planilha (Arquivo > Publicar na Web > selecionar a aba > formato CSV)
const SHEET_CSV_URL = 'COLE_AQUI_O_LINK_CSV_PUBLICADO';

// Mapeamento de cabeçalhos esperados na planilha
// rank, name, username, profile_url, followers, last_checked
function normalizeHeader(h){
  return (h || '').toString().trim().toLowerCase();
}

function fmtNumber(n){
  try {
    return new Intl.NumberFormat('pt-BR').format(Number(n||0));
  } catch(e){ return n; }
}

function initTable(rows){
  const tbody = document.querySelector('#igTable tbody');
  tbody.innerHTML = '';
  rows.forEach(r => {
    const tr = document.createElement('tr');
    const followersNum = Number(r.followers || 0);
    tr.innerHTML = `
      <td>${r.rank || ''}</td>
      <td>${r.name || ''}</td>
      <td><a href="${r.profile_url || '#'}" target="_blank" rel="noopener">@${r.username || ''}</a></td>
      <td data-order="${followersNum}">${fmtNumber(followersNum)}</td>
      <td>${r.last_checked || ''}</td>
    `;
    tbody.appendChild(tr);
  });

  // DataTables
  jQuery('#igTable').DataTable({
    order: [[3, 'desc']],
    pageLength: 25,
    responsive: true,
    language: { url: 'https://cdn.datatables.net/plug-ins/2.0.3/i18n/pt-BR.json' }
  });
}

function loadCSV(){
  if (!SHEET_CSV_URL || SHEET_CSV_URL.includes('COLE_AQUI_O_LINK_CSV_PUBLICADO')) {
    document.getElementById('lastUpdated').textContent = '⚠️ Configure o SHEET_CSV_URL em assets/app.js';
    return;
  }
  Papa.parse(SHEET_CSV_URL, {
    header: true,
    download: true,
    skipEmptyLines: true,
    complete: (res) => {
      const data = res.data || [];
      const rows = data.map(row => {
        // normaliza chaves independente de capitalização
        const obj = {};
        Object.keys(row).forEach(k => obj[normalizeHeader(k)] = row[k]);
        return {
          rank: obj['rank'],
          name: obj['name'],
          username: obj['username'],
          profile_url: obj['profile_url'],
          followers: obj['followers'],
          last_checked: obj['last_checked']
        };
      }).filter(x => x.username);

      // atualiza label de "last updated" com a hora do browser (a planilha também tem last_checked por linha)
      const now = new Date();
      document.getElementById('lastUpdated').textContent =
        'Atualizado agora: ' + new Intl.DateTimeFormat('pt-BR', { dateStyle:'medium', timeStyle:'short' }).format(now);

      initTable(rows);
    },
    error: (err) => {
      document.getElementById('lastUpdated').textContent = 'Erro ao carregar CSV: ' + (err && err.message ? err.message : 'desconhecido');
    }
  });
}

document.addEventListener('DOMContentLoaded', loadCSV);
